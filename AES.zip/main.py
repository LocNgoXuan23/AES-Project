from gen_aes import genAES

if __name__ == '__main__':
    genAES(8000, 'my_cipher.txt')